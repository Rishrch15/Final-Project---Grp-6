package pkgcase.study;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ConnectionClass {

    public Connection con;
    public Connection conRM;

    public ConnectionClass() {
        connect();
        connectRm(); // Ensure both connections are established
    }

    private void connect() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://192.168.56.186:3306/hotelmanagement_db", "root", "");
            System.out.println("Connection to hotelmanagement_db Successful!");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ConnectionClass.class.getName()).log(Level.SEVERE, "JDBC Driver not found", ex);
        } catch (SQLException ex) {
            Logger.getLogger(ConnectionClass.class.getName()).log(Level.SEVERE, "Database connection failed", ex);
        }
    }

    private void connectRm() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conRM = DriverManager.getConnection("jdbc:mysql://192.168.56.186:3306/hotelmanagement_rm", "root", "");
            System.out.println("Connection to hotelmanagement_rm Successful!");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ConnectionClass.class.getName()).log(Level.SEVERE, "JDBC Driver not found", ex);
        } catch (SQLException ex) {
            Logger.getLogger(ConnectionClass.class.getName()).log(Level.SEVERE, "Database connection failed", ex);
        }
    }

    // Add a parameter to specify which connection to return
    public Connection getConnection(String dbName) {
        if ("hotelmanagement_db".equals(dbName)) {
            return con;
        } else if ("hotelmanagement_rm".equals(dbName)) {
            return conRM;
        } else {
            return null; // Return null if the database name is incorrect
        }
    }
}
