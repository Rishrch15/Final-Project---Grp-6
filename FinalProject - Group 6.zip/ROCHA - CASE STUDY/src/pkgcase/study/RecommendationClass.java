package pkgcase.study;

import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class RecommendationClass {

    Connection con; // Connection for hotelmanagement_db
    Connection conRM; // Connection for hotelmanagement_rm

    String seasonRow; // Row name for the selected season
    String destinationTable; // Table name for the destination type (local or international)

    // Room availability
    int standardAvailable, deluxeAvailable, quadrupleAvailable, familyAvailable, suiteAvailable;
    // Room prices
    int standardPrice, deluxePrice, quadruplePrice, familyPrice, suitePrice;

    // Recommendation variables
    String recommendedRoom = "No recommended room";
    int recommendedNumberOfRooms = 0;
    int recommendedExtraBeds = 0;
    String recommendRoomSentence = "No suitable rooms available.";
    int recommendedRoomPrice;

    // Current booking information
    int daysOfStay;
    int totalRoomCost;
    String destination;
    String season;
    String reservationNumber;
    String idNumber;
    int freeChild = 0;
    int paidChild = 0;
    int adultGuests;

    public RecommendationClass() {
        connect();
    }

    // Establish connections to both databases
    private void connect() {
        try {
            ConnectionClass connectionClass = new ConnectionClass();
            con = connectionClass.con;      // Connection for hotelmanagement_db
            conRM = connectionClass.conRM;  // Connection for hotelmanagement_rm
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error connecting to the database: " + e.getMessage());
        }
    }

    public void processGuests(String dest,int adultGuests, int childGuests, JComboBox<String>[] childAgeSelectors, String destinationType, String ssn, int days, String reservationNo, String idNum) {
    this.adultGuests = adultGuests; // Assign parameter value to the field
    daysOfStay = days;
    season = ssn;
    destination = dest;
    reservationNumber = reservationNo;
    idNumber = idNum;

    int[] childAges = new int[childGuests];
    destinationTable = destinationType;
    seasonRow = getSeasonColumn(season);

    getChildAges(childAges, childAgeSelectors);
    getRoomPrice();
    getAvailableRoom();
    recommendRoom(childGuests, childAges);
    getFinalRoomPrice();
    toNextPage();
}


    private String getSeasonColumn(String season) {
        switch (season.toLowerCase()) {
            case "lean season":
                return "lean";
            case "high season":
                return "high";
            case "peak season":
                return "peak";
            case "super peak season":
                return "superPeak";
            default:
                throw new IllegalArgumentException("Invalid season: " + season);
        }
    }

    private void getRoomPrice() {
        String query = "SELECT * FROM " + destinationTable + " WHERE season = ?";
        try (PreparedStatement statement = conRM.prepareStatement(query)) {
            statement.setString(1, seasonRow);
            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    standardPrice = rs.getInt("standard");
                    deluxePrice = rs.getInt("deluxe");
                    quadruplePrice = rs.getInt("quadruple");
                    familyPrice = rs.getInt("family");
                    suitePrice = rs.getInt("suite");
                } else {
                    JOptionPane.showMessageDialog(null, "No price data found for season: " + seasonRow);
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error fetching room prices: " + e.getMessage());
        }
    }

    private void getAvailableRoom() {
        String query = "SELECT * FROM availableroom WHERE label = 'roomAvailable'";
        try (PreparedStatement statement = conRM.prepareStatement(query)) {
            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    standardAvailable = rs.getInt("standard");
                    deluxeAvailable = rs.getInt("deluxe");
                    quadrupleAvailable = rs.getInt("quadruple");
                    familyAvailable = rs.getInt("family");
                    suiteAvailable = rs.getInt("suite");
                } else {
                    JOptionPane.showMessageDialog(null, "No availability data found.");
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error fetching room availability: " + e.getMessage());
        }
    }

    private void getChildAges(int[] childAges, JComboBox<String>[] childAgeSelectors) {
        for (int i = 0; i < childAges.length; i++) {
            String ageStr = (String) childAgeSelectors[i].getSelectedItem();
            if (ageStr != null) {
                try {
                    childAges[i] = Integer.parseInt(ageStr);
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(null, "Invalid age input for child " + (i + 1));
                    return;
                }
            } else {
                JOptionPane.showMessageDialog(null, "Please select an age for child " + (i + 1));
                return;
            }
        }
    }

    private void recommendRoom(int childGuests, int[] childAges) {
        freeChild = 0;
        paidChild = 0;

        for (int age : childAges) {
            if (age < 8) {
                freeChild++;
            } else if (age <= 17) {
                paidChild++;
            }
        }

        int totalGuests = adultGuests + paidChild + freeChild;

        if (totalGuests <= 2 && standardAvailable >= 1) {
            recommendedRoom = "Standard";
            recommendedNumberOfRooms = 1;
        } else if (totalGuests <= 4 && deluxeAvailable >= 1) {
            recommendedRoom = "Deluxe";
            recommendedNumberOfRooms = 1;
        } else if (totalGuests <= 6 && quadrupleAvailable >= 1) {
            recommendedRoom = "Quadruple";
            recommendedNumberOfRooms = 1;
        } else {
            int roomsNeeded = (int) Math.ceil(totalGuests / 6.0);
            if (familyAvailable >= roomsNeeded) {
                recommendedRoom = "Family";
                recommendedNumberOfRooms = roomsNeeded;
            } else {
                recommendRoomSentence = "No suitable rooms available.";
                return;
            }
        }

        recommendRoomSentence = formatRecommendation(recommendedRoom, recommendedNumberOfRooms, recommendedExtraBeds);
    }

    private String formatRecommendation(String roomType, int rooms, int beds) {
        return rooms + " " + roomType + " room(s)" + (beds > 0 ? " with " + beds + " extra bed(s)" : "");
    }

    private void getFinalRoomPrice() {
        recommendedRoomPrice = getRoomPriceByType(recommendedRoom);
    }

    private int getRoomPriceByType(String roomType) {
        switch (roomType) {
            case "Standard":
                return standardPrice;
            case "Deluxe":
                return deluxePrice;
            case "Quadruple":
                return quadruplePrice;
            case "Family":
                return familyPrice;
            case "Suite":
                return suitePrice;
            default:
                return 0;
        }
    }

    private void toNextPage() {
        RoomType instancesForRT = new RoomType();
        totalRoomCost = recommendedNumberOfRooms * recommendedRoomPrice * daysOfStay;
        System.out.println("avail " + adultGuests);
        instancesForRT.reservationNum.setText(reservationNumber);
        instancesForRT.idNumber.setText(idNumber);
        instancesForRT.season.setText(season);
        instancesForRT.destination.setText(destination);
        instancesForRT.getValue(destination,recommendedRoom, recommendedNumberOfRooms, recommendedRoomPrice, totalRoomCost, daysOfStay, season, idNumber, reservationNumber,standardAvailable,deluxeAvailable,quadrupleAvailable,familyAvailable,suiteAvailable,standardPrice, deluxePrice, quadruplePrice, familyPrice, suitePrice, adultGuests,paidChild,freeChild);
        instancesForRT.paidGuestCount.setText(String.valueOf(paidChild + adultGuests));
        instancesForRT.childGuestsCount.setText(String.valueOf(freeChild));
        instancesForRT.setVisible(true);
        
        
        
        
    }
}
